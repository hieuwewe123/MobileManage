create function search_invoices_by_customer(p_keyword text)
    returns TABLE(id integer, customer_id integer, created_at timestamp without time zone, total_amount numeric, customer_name character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT
            i.id,
            i.customer_id,
            i.created_at,
            i.total_amount,
            c.name as customer_name
        FROM invoice i
                 LEFT JOIN customer c ON i.customer_id = c.id
        WHERE LOWER(c.name) LIKE LOWER('%' || p_keyword || '%')
        ORDER BY i.id DESC;
END;
$$;

alter function search_invoices_by_customer(text) owner to postgres;

