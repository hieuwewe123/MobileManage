create function search_products_by_keyword(p_keyword character varying)
    returns TABLE(id integer, name character varying, brand character varying, price numeric, stock integer)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT p.id, p.name, p.brand, p.price, p.stock
        FROM product p
        WHERE p.name ILIKE '%' || p_keyword || '%'
           OR p.brand ILIKE '%' || p_keyword || '%'
        ORDER BY p.brand, p.name;
END;
$$;

alter function search_products_by_keyword(varchar) owner to postgres;

