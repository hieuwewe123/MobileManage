create procedure update_customer(IN p_id integer, IN p_name character varying, IN p_phone character varying, IN p_email character varying, IN p_address character varying)
    language plpgsql
as
$$
BEGIN
    UPDATE customer
    SET name = TRIM(p_name),
        phone = TRIM(p_phone),
        email = TRIM(p_email),
        address = TRIM(p_address)
    WHERE id = p_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Không tìm thấy khách hàng với ID %', p_id;
    END IF;
END;
$$;

alter procedure update_customer(integer, varchar, varchar, varchar, varchar) owner to postgres;

