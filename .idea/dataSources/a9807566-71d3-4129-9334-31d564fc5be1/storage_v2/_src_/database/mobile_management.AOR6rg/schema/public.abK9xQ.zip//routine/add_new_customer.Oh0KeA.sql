create procedure add_new_customer(IN p_name character varying, IN p_phone character varying, IN p_email character varying, IN p_address character varying)
    language plpgsql
as
$$
BEGIN
    INSERT INTO customer (name, phone, email, address)
    VALUES (TRIM(p_name), TRIM(p_phone), TRIM(p_email), TRIM(p_address));
END;
$$;

alter procedure add_new_customer(varchar, varchar, varchar, varchar) owner to postgres;

