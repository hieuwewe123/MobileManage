create function get_revenue_by_year()
    returns TABLE(nam character varying, tong_doanh_thu numeric)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT
            TO_CHAR(i.created_at, 'YYYY') as nam,
            SUM(i.total_amount) as tong_doanh_thu
        FROM invoice i
        GROUP BY TO_CHAR(i.created_at, 'YYYY')
        ORDER BY nam DESC;
END;
$$;

alter function get_revenue_by_year() owner to postgres;

