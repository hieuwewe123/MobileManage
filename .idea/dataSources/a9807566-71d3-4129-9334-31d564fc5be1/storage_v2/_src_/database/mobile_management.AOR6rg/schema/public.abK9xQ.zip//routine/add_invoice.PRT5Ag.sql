create function add_invoice(p_customer_id integer, p_total_amount numeric) returns integer
    language plpgsql
as
$$
DECLARE
    new_id INTEGER;
BEGIN
    INSERT INTO invoice (customer_id, total_amount)
    VALUES (p_customer_id, p_total_amount)
    RETURNING id INTO new_id;

    RETURN new_id;
END;
$$;

alter function add_invoice(integer, numeric) owner to postgres;

