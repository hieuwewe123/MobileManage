create function add_invoice(p_customer_id integer) returns integer
    language plpgsql
as
$$
DECLARE
    new_invoice_id INT;
BEGIN
    IF NOT EXISTS (SELECT 1 FROM customer WHERE id = p_customer_id) THEN
        RETURN -1;
    END IF;

    INSERT INTO invoice (customer_id, created_at, total_amount)
    VALUES (p_customer_id, NOW(), 0)
    RETURNING id INTO new_invoice_id;

    RETURN new_invoice_id;
END;
$$;

alter function add_invoice(integer) owner to postgres;

