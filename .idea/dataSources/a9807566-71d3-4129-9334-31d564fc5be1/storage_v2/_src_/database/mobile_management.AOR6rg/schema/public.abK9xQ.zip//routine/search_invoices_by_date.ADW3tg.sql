create function search_invoices_by_date(p_date_str text)
    returns TABLE(id integer, customer_id integer, created_at timestamp without time zone, total_amount numeric, customer_name character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT
            i.id,
            i.customer_id,
            i.created_at,
            i.total_amount,
            c.name as customer_name
        FROM invoice i
                 LEFT JOIN customer c ON i.customer_id = c.id
        WHERE TO_CHAR(i.created_at, 'YYYY-MM-DD') LIKE p_date_str || '%'
           OR TO_CHAR(i.created_at, 'YYYY-MM') = p_date_str
           OR TO_CHAR(i.created_at, 'YYYY') = p_date_str
        ORDER BY i.id DESC;
END;
$$;

alter function search_invoices_by_date(text) owner to postgres;

