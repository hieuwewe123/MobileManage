create function get_all_products()
    returns TABLE(id integer, name character varying, brand character varying, price numeric, stock integer)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT p.id, p.name, p.brand, p.price, p.stock
        FROM product p
        ORDER BY p.brand, p.name;
END;
$$;

alter function get_all_products() owner to postgres;

