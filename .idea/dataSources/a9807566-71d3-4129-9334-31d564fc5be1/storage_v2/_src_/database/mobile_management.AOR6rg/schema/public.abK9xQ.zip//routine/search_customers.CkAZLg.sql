create function search_customers(p_keyword character varying)
    returns TABLE(id integer, name character varying, phone character varying, email character varying, address character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT
            c.id,
            c.name,
            c.phone,
            c.email,
            c.address
        FROM customer c
        WHERE c.name ILIKE '%' || COALESCE(p_keyword, '') || '%'
           OR c.phone ILIKE '%' || COALESCE(p_keyword, '') || '%'
           OR c.email ILIKE '%' || COALESCE(p_keyword, '') || '%'
        ORDER BY c.name;
END;
$$;

alter function search_customers(varchar) owner to postgres;

