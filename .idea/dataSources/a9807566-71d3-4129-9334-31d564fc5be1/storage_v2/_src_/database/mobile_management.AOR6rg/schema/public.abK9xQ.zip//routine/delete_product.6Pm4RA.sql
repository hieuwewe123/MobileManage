create procedure delete_product(IN p_id integer)
    language plpgsql
as
$$
BEGIN
    DELETE FROM product WHERE id = p_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Không tìm thấy sản phẩm với ID %', p_id;
    END IF;
END;
$$;

alter procedure delete_product(integer) owner to postgres;

