create procedure add_invoice_detail(IN p_invoice_id integer, IN p_product_id integer, IN p_quantity integer, IN p_unit_price numeric)
    language plpgsql
as
$$
BEGIN
    BEGIN
        -- Thêm chi tiết hóa đơn
        INSERT INTO invoice_detail (invoice_id, product_id, quantity, unit_price)
        VALUES (p_invoice_id, p_product_id, p_quantity, p_unit_price);

        -- Cập nhật tồn kho sản phẩm
        UPDATE product
        SET stock = stock - p_quantity
        WHERE id = p_product_id;

        -- Cập nhật tổng tiền hóa đơn (tính lại từ tất cả invoice_detail)
        UPDATE invoice
        SET total_amount = COALESCE((
                                        SELECT SUM(quantity * unit_price)
                                        FROM invoice_detail
                                        WHERE invoice_id = p_invoice_id
                                    ), 0)
        WHERE id = p_invoice_id;

    EXCEPTION WHEN OTHERS THEN
        RAISE EXCEPTION 'Lỗi khi thêm chi tiết hóa đơn: %', SQLERRM;
    END;
END;
$$;

alter procedure add_invoice_detail(integer, integer, integer, numeric) owner to postgres;

