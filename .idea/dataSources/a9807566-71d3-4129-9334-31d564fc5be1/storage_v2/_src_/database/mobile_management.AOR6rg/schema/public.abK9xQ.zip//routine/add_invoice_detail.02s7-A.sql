create procedure add_invoice_detail(IN p_invoice_id integer, IN p_product_id integer, IN p_quantity integer, IN p_unit_price numeric)
    language plpgsql
as
$$
BEGIN
    INSERT INTO invoice_detail (invoice_id, product_id, quantity, unit_price)
    VALUES (p_invoice_id, p_product_id, p_quantity, p_unit_price);

    -- Trừ tồn kho sản phẩm
    UPDATE product
    SET stock = stock - p_quantity
    WHERE id = p_product_id AND stock >= p_quantity;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Không đủ tồn kho cho sản phẩm ID %', p_product_id;
    END IF;
END;
$$;

alter procedure add_invoice_detail(integer, integer, integer, numeric) owner to postgres;

