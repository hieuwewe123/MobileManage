create function check_admin_login(p_username character varying, p_password character varying) returns boolean
    language plpgsql
as
$$
BEGIN
    RETURN EXISTS (
        SELECT 1
        FROM admin
        WHERE username = TRIM(p_username)
          AND password = TRIM(p_password)
    );
END;
$$;

alter function check_admin_login(varchar, varchar) owner to postgres;

