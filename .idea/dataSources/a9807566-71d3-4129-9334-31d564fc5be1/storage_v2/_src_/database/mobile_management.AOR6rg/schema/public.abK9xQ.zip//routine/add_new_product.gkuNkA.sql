create procedure add_new_product(IN p_name character varying, IN p_brand character varying, IN p_price numeric, IN p_stock integer)
    language plpgsql
as
$$
BEGIN
    INSERT INTO product (name, brand, price, stock)
    VALUES (p_name, p_brand, p_price, p_stock);

END;
$$;

alter procedure add_new_product(varchar, varchar, numeric, integer) owner to postgres;

