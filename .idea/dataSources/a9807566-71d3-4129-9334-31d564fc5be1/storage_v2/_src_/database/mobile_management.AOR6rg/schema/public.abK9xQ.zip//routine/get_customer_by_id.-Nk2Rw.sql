create function get_customer_by_id(p_id integer)
    returns TABLE(id integer, name character varying, phone character varying, email character varying, address character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT
            c.id,
            c.name,
            c.phone,
            c.email,
            c.address
        FROM customer c
        WHERE c.id = p_id;
END;
$$;

alter function get_customer_by_id(integer) owner to postgres;

