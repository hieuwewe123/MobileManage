create function get_revenue_by_day()
    returns TABLE(ngay date, tong_doanh_thu numeric)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT DATE(i.created_at) AS ngay,
               SUM(i.total_amount) AS tong_doanh_thu
        FROM invoice i
        GROUP BY DATE(i.created_at)
        ORDER BY ngay DESC;
END;
$$;

alter function get_revenue_by_day() owner to postgres;

