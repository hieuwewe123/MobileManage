create function get_all_invoices()
    returns TABLE(id integer, customer_id integer, customer_name character varying, created_at timestamp without time zone, total_amount numeric)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT i.id, i.customer_id, c.name AS customer_name, i.created_at, i.total_amount
        FROM invoice i
                 JOIN customer c ON i.customer_id = c.id
        ORDER BY i.created_at DESC;
END;
$$;

alter function get_all_invoices() owner to postgres;

