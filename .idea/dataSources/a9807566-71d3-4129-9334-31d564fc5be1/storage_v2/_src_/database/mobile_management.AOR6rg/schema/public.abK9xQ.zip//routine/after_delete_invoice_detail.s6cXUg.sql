create function after_delete_invoice_detail() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE invoice
    SET total_amount = COALESCE((
                                    SELECT SUM(quantity * unit_price)
                                    FROM invoice_detail
                                    WHERE invoice_id = OLD.invoice_id
                                ), 0)
    WHERE id = OLD.invoice_id;

    RETURN OLD;
END;
$$;

alter function after_delete_invoice_detail() owner to postgres;

