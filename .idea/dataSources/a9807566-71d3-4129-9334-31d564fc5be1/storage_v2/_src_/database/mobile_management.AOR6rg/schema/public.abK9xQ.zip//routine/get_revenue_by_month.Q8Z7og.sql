create function get_revenue_by_month()
    returns TABLE(thang text, tong_doanh_thu numeric)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT TO_CHAR(i.created_at, 'YYYY-MM') AS thang,
               SUM(i.total_amount) AS tong_doanh_thu
        FROM invoice i
        GROUP BY TO_CHAR(i.created_at, 'YYYY-MM')
        ORDER BY thang DESC;
END;
$$;

alter function get_revenue_by_month() owner to postgres;

