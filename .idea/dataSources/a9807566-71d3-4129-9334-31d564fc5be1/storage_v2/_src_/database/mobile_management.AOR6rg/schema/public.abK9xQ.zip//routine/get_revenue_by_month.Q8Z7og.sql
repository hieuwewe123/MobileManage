create function get_revenue_by_month()
    returns TABLE(thang character varying, tong_doanh_thu numeric)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT
            TO_CHAR(i.created_at, 'YYYY-MM') as thang,
            SUM(i.total_amount) as tong_doanh_thu
        FROM invoice i
        GROUP BY TO_CHAR(i.created_at, 'YYYY-MM')
        ORDER BY thang DESC;
END;
$$;

alter function get_revenue_by_month() owner to postgres;

