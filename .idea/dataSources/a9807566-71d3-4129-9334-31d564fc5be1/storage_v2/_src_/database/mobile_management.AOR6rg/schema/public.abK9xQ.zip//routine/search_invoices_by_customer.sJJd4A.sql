create function search_invoices_by_customer(p_keyword character varying)
    returns TABLE(id integer, customer_id integer, customer_name character varying, created_at timestamp without time zone, total_amount numeric)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT i.id, i.customer_id, c.name AS customer_name, i.created_at, i.total_amount
        FROM invoice i
                 JOIN customer c ON i.customer_id = c.id
        WHERE c.name ILIKE '%' || COALESCE(p_keyword, '') || '%'
        ORDER BY i.created_at DESC;
END;
$$;

alter function search_invoices_by_customer(varchar) owner to postgres;

