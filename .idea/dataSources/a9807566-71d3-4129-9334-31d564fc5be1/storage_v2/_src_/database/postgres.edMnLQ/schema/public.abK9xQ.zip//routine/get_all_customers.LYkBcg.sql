create function get_all_customers()
    returns TABLE(id integer, name character varying, phone character varying, email character varying, address character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT * FROM customer ORDER BY name;
END;
$$;

alter function get_all_customers() owner to postgres;

