create function get_products_by_price_range(p_min numeric, p_max numeric)
    returns TABLE(id integer, name character varying, brand character varying, price numeric, stock integer)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT p.id, p.name, p.brand, p.price, p.stock
        FROM product p
        WHERE p.price BETWEEN p_min AND p_max
        ORDER BY p.price;
END;
$$;

alter function get_products_by_price_range(numeric, numeric) owner to postgres;

