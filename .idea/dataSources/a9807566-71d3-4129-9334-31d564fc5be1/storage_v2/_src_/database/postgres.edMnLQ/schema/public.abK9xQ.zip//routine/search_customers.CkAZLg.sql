create function search_customers(p_keyword character varying)
    returns TABLE(id integer, name character varying, phone character varying, email character varying, address character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT * FROM customer
        WHERE name  ILIKE '%' || COALESCE(p_keyword, '') || '%'
           OR phone ILIKE '%' || COALESCE(p_keyword, '') || '%'
           OR email ILIKE '%' || COALESCE(p_keyword, '') || '%'
        ORDER BY name;
END;
$$;

alter function search_customers(varchar) owner to postgres;

